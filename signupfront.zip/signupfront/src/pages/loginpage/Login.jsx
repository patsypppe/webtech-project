import { useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import './Login2.css'


const Login = () => {
	const [data, setData] = useState({ email: "", password: "" });
	const [error, setError] = useState("");

	const handleChange = ({ currentTarget: input }) => {
		setData({ ...data, [input.name]: input.value });
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		try {
			const url = "http://localhost:4000/api/auth";
			const { data: res } = await axios.post(url, data);
			localStorage.setItem("token", res.data);
			window.location = "/";
		} catch (error) {
			if (
				error.response &&
				error.response.status >= 400 &&
				error.response.status <= 500
			) {
				setError(error.response.data.message);
			}
		}
	};

	return (
		<div className="login_container">
			
			<div className="full-form_container">
				
				<div className="left">
						
					<form className="form_container" onSubmit={handleSubmit}>
						<h1 className="header">Login to Your Account</h1>
						<input
							type="email"
							placeholder="Email"
							name="email"
							className="input"
							onChange={handleChange}
							value={data.email}
							required
							
						/>
						<input className="input"
							type="password"
							placeholder="Password"
							name="password"
							onChange={handleChange}
							value={data.password}
							required
							
						/>
						{error && <div className="error_msg" >{error}</div>}
						<button className="green_btn" type="submit">
							Sign In
						</button>
					</form>
				</div>
				<div className="right">
					<h1>New Here ?</h1>
					<Link to="/signup">
						<button className="white_btn" type="button" >
							Sign Up
						</button>
					</Link>
				</div>
			</div>
		</div>
	);
};

export default Login;